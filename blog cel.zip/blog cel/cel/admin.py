from django.contrib import admin

from.models import cel, likes

admin.site.register(cel)
admin.site.register(likes)