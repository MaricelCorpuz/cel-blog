from django import forms
from .models import Meal

class hobbiesForm(forms.ModelForm):
	class Meta:
		model = likes
		fields = "__all__"