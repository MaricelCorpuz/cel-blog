from django.apps import AppConfig


class celConfig(AppConfig):
    name = 'cel'
