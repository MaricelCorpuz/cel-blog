from django.db import models

class cel(models.Model):
	name = models.CharField(verbose_name="cel Name", max_length=200)
	likes = models.FloatField(verbose_name="Calories (kcal)")
	hobbies = models.FloatField(verbose_name="Total Fat (g)")
	

	def __str__(self):
		return "%s" % self.name

from django.db import models

class cel(models.Model):
	current = 1
	past = 1
	future = 3
	
	MEAL_TIME_TYPES = (
		(current, "current"),
		(past, "past"),
		(future, "future"),
		
	)
	likes = models.ForeignKey(Food, verbose_name="likes",on_delete = models.CASCADE)
	hobbies = models.IntegerField(verbose_name="hobbies")
	activities = models.IntegerField(verbose_name="activities", choices=MEAL_TIME_TYPES)

	def_str_(self):
		return "%s" % self.food

	def likes(self):
		return self.serving_size * self.food.calories